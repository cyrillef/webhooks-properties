'use strict';

var RightShadowMaterial = "SplitScreen_RightGroundShadowMaterial";

// Proxy to manage 2 separate GroundShadows for split screen
export function SplitScreenGroundShadow() {

    this.attach = function(viewer) {

        this.renderer = viewer.impl.glrenderer();

        // Reuse existing ground shadow for left screen and create a separate GroundShadow for the right one.
        this.leftShadow  = viewer.impl.setUserGroundShadow(this);
        this.rightShadow = new Autodesk.Viewing.Private.GroundShadow(this.renderer);

        // Make sure that override materials get current cutplanes from MaterialManager
        var materials = viewer.impl.getMaterials();
        materials.addMaterialNonHDR(RightShadowMaterial, this.rightShadow.getDepthMaterial());

        // Sync right ground-shadow settings with the original one
        this.rightShadow.enabled = this.leftShadow.enabled;    
        this.rightShadow.setColor(this.leftShadow.getColor());
        this.rightShadow.setAlpha(this.leftShadow.getAlpha());

        // force ground shadow update (including transform reset)
        viewer.impl.sceneUpdated();
    };

    this.detach = function(viewer) {

        // clean up secondary ground shadow material
        var materials = viewer.impl.getMaterials();
        materials.removeNonHDRMaterial(RightShadowMaterial);

        // recover original ground shadow
        viewer.impl.setUserGroundShadow(this.leftShadow);
        viewer.impl.sceneUpdated();
    };

    // Create function that forwards a function call to left/right GroundShadow. Return values are taken
    // from the right one. (We can use any, because we keep them in sync)
    this.createForward = function(funcName) {
        this[funcName] = function() {
            this.leftShadow[funcName].apply(this.leftShadow, arguments);
            return this.rightShadow[funcName].apply(this.rightShadow, arguments);
        }.bind(this);
    };

    var forwards = [        
        "setTransform",
        "setDirty",
        "prepareGroundShadow",
        "getStatus",
        "clear",
        "setColor",
        "setAlpha"
    ];
    for (var i in forwards) {
        this.createForward(forwards[i]);
    }
    
    Object.defineProperty(this, 'enabled', {
        get: function() { 
            return this.leftShadow.enabled;
        },
        set: function(enabled) { 
            this.leftShadow.enabled  = enabled; 
            this.rightShadow.enabled = enabled;
        }
    });

    Object.defineProperty(this, 'rendered', {
        get: function() { 
            return this.leftShadow.rendered;
        },
        set: function(rendered) { 
            this.leftShadow.rendered  = rendered; 
            this.rightShadow.rendered = rendered;
        }
    });

    this.renderShadow = function(camera, target) {

        // Note that the camera is already set to half canvas width
        var halfW  = camera.clientWidth;
        var height = camera.clientHeight;

        this.renderer.setViewport(0, 0, halfW, height);
        this.leftShadow.renderShadow(camera, target);

        this.renderer.setViewport(halfW, 0, halfW, height);
        this.rightShadow.renderShadow(camera, target);        
    };
}
